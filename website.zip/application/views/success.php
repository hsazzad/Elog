
<!DOCTYPE html>
<html lang="en">
  <head>
    
   
    <link rel="icon" href="<?php echo base_url();?>images/Lock1.ico">
    <title>Registration</title>
    <link href="<?php echo base_url();?>css/css/bootstrap.css" rel="stylesheet">
    <link href="<?php echo base_url();?>css/css/bootstrap.min.css" rel="stylesheet">
<style>

body {
   padding-top: 40px;
  padding-bottom: 40px;
  background-color: #eee;
}

</style>
	
	<script src="<?php echo base_url();?>css/js/jquery.min.js"></script>
	<script src="<?php echo base_url();?>css/js/bootstrap.min.js"></script>
	<script src="<?php echo base_url();?>css/js/bootstrap.js"></script>
  </head>

  <body>
<div class="alert alert-success">
 <p>Your Form has been successfully submitted. Please <a href="<?php  $this->load->helper('url'); echo site_url("login"); ?>">Click Here</a> to go to Login Page</p><div>
  </body>
</html>
